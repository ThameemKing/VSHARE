import "package:flutter/material.dart";

const Color lightGreenColor = Color.fromRGBO(14, 60, 42, 1);
const Color primaryColor = Color.fromRGBO(9, 34, 27, 1);
const Color greyColor = Color.fromRGBO(134, 149, 146, 1);
const Color lighterGreenColor = Color.fromRGBO(38, 61, 53, 1);
const Color yellowColor = Color.fromRGBO(229, 213, 152, 1);
